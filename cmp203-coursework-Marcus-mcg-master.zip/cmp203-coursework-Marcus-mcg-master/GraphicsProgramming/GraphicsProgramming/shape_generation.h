#pragma once

#include "glut.h"
#include <gl/gl.h>
#include <gl/glu.h>
#include <math.h> 
#define PI 3.14159265


class shape_generation
{
public:
	void disc(int vertices, int scale);
	void cylinder(int vertices);
	void sphere(int vertices);




};

