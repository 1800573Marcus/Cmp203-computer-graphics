// Scene class. Configures a basic 3D scene.
// Interfaces with the Input class to handle user input
// Calculates and outputs Frames Per Second (FPS) rendered.
// Important functions are the constructor (initialising the scene), 
// update (for process user input and updating scene objects) and render (renders scene).
#ifndef _SCENE_H
#define _SCENE_H

// Include GLUT, openGL, input.
#include "glut.h"
#include <gl/GL.h>
#include <gl/GLU.h>
#include "Input.h"
#include <stdio.h>
// Further includes should go here:
#include "SOIL.h"
#include <vector>
#include "Shape.h"
#include "shape_generation.h"
#include "Model.h"
#include "Camera.h"

class Scene{

public:
	Scene(Input *in);
	// Main render function
	void render();
	// Handle input function that receives delta time from parent.
	void handleInput(float dt);
	// Update function receives delta time from parent (used for frame independent updating).
	void update(float dt);
	// Resizes the OpenGL output based on new window size.
	void resize(int w, int h);

	void skybox();


protected:
	// Renders text (x, y positions, RGB colour of text, string of text to be rendered)
	void displayText(float x, float y, float r, float g, float b, char* string);
	// A function to collate all text output in a single location
	void renderTextOutput();
	void calculateFPS();

	// draw primitive functions
	

	// For access to user input.
	Input* input;
		
	// For Window and frustum calculation.
	int width, height;
	float fov, nearPlane, farPlane;

	// For FPS counter and mouse coordinate output.
	int frame = 0, time, timebase = 0;
	char fps[40];
	char mouseText[40];

	bool pressed = false;
	float rotation;
	float speed = 100;
	float camrotate = 0.05;

	bool camset = 0;
	
	float mousexpos = 0;
	float mouseypos = 0;
	float mousemoved = 0;
	float centrex = width /2;
	float centrey = height / 2;
	Camera cam;
	Camera cam2;
	Camera* currentcam;
	Shape r1;
	GLuint myTexture;
	GLuint soratext;
	GLuint roxastext;
	GLuint skytextfront;
	GLuint skytextback;
	GLuint skytextleft;
	GLuint skytextright;
	GLuint skytextup;
	GLuint skytextdown;
	GLuint keytext;
	GLuint keytext2;
	GLuint brick;
	GLuint shadow;
	shape_generation myshape;
	Model model;
	Model roxas;
	Model key;
	Model key2;
};

#endif