#include "shape.h"


extern float verts[] = {
							-1.0, 1.0, 1.0,			// Vertex #0 front
							-1.0, -1.0, 1.0,		// Vertex #1
							1.0,  -1.0, 1.0,		// Vertex #2
							1.0,  1.0, 1.0,			// Vertex #3

							1.0,  1.0, -1.0,		// bacl
							1.0,  -1.0, -1.0,
							-1.0, -1.0, -1.0,
							-1.0, 1.0, -1.0,

							1,1,1,				//right
							1,-1,1,
							1,-1,-1,
							1,1,-1,

							-1,-1,1,				//left
							-1,1,1,	
							-1,1,-1,
							-1,-1,-1,
							
							-1,1,-1,				// top
							-1,1,1,
							1,1,1,
							1,1,-1,

							-1,-1,1,				// bottom
							-1,-1,-1,
							1,-1,-1,
							1,-1,1,
							
							
							
				
							
							

							
						};

extern float norms[] = { 0.0, 0.0, 1.0,		//0
						0.0, 0.0, 1.0,		//1 front
 						0.0, 0.0, 1.0,		//2
						0.0, 0.0, 1.0,		//3

						0.0, 0.0, -1.0,		//0
						0.0, 0.0, -1.0,		//1 back
						0.0, 0.0, -1.0,		//2
						0.0, 0.0, -1.0,		//3

						1.0, 0.0, 0.0,		//0 right
						1.0, 0.0, 0.0,		//1
						1.0, 0.0, 0.0,		//2
						1.0, 0.0, 0.0,		//3
						
						-1.0, 0.0, 0.0,		//0 left
						-1.0, 0.0, 0.0,		//1
						-1.0, 0.0, 0.0,		//2
						-1.0, 0.0, 0.0,		//3

						 0.0, 1.0, 0.0,		//0top
						0.0, 1.0, 0.0,		//1
						0.0, 1.0, 0.0,		//2
						0.0, 1.0, 0.0,		//3
					
						0.0, -1.0, 0.0,		//0 bottom
						0.0, -1.0, 0.0,		//1
						0.0, -1.0, 0.0,		//2
						0.0, -1.0, 0.0,		//3
						




						};		


extern float texcoords[]= {

							0.0, 0.0, 		//0
							0.0, 1.0, 		//1
 							1.0, 1.0, 		//2
							1.0, 0.0, 		//3

							0.0, 0.0, 		//0
							0.0, 1.0, 		//1
							1.0, 1.0, 		//2
							1.0, 0.0, 		//3

							0.0, 0.0, 		//0
							0.0, 1.0, 		//1
							1.0, 1.0, 		//2
							1.0, 0.0, 		//3

							0.0, 0.0, 		//0
							0.0, 1.0, 		//1
							1.0, 1.0, 		//2
							1.0, 0.0, 		//3

							0.0, 0.0, 		//0
							0.0, 1.0, 		//1
							1.0, 1.0, 		//2
							1.0, 0.0, 		//3

							0.0, 0.0, 		//0
							0.0, 1.0, 		//1
							1.0, 1.0, 		//2
							1.0, 0.0, 		//3

							};

void Shape::render1()
{
	// add code to render the cube (above) using method 1
	// glArrayElement()
	glEnableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_NORMAL_ARRAY);
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);

	glVertexPointer(3, GL_FLOAT, 0, verts);
	glNormalPointer(GL_FLOAT, 0, norms);
	glTexCoordPointer(2, GL_FLOAT, 0, texcoords);

	


	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_NORMAL_ARRAY);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);

}

void Shape::render2()
{
	// add code to render the cube (above) using method 2
	// glDrawArrays()

	glEnableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_NORMAL_ARRAY);
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);

	glVertexPointer(3, GL_FLOAT, 0, verts);
	glNormalPointer(GL_FLOAT, 0, norms);
	glTexCoordPointer(2, GL_FLOAT, 0, texcoords);

	glDrawArrays(GL_QUADS, 0, 24);

	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_NORMAL_ARRAY);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);

}

void Shape::render3()
{
	// add code to render the cube (above) using method 3
	// glDrawElements()

}


