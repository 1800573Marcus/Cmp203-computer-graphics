#include "shape_generation.h"




void shape_generation::disc(int vertices, int scale) {

	float interval = (2 * PI) / vertices;
	float angle = 0.0f;
	glBegin(GL_TRIANGLES);
	for (int i = 0; i < vertices; i++){
		
		glTexCoord2f(0.5, 0.5);//centre
		glVertex3f(0, 0, 0);


		glNormal3f(0, 0, 1);
		glTexCoord2f(cos(angle)/2 +0.5, sin(angle)/2+0.5);
		glVertex3f(scale*cos(angle), scale*sin(angle), 0);

		glNormal3f(0, 0, 1);
		glTexCoord2f(cos(angle+interval) / 2 + 0.5, sin(angle+interval) / 2 + 0.5);
		glVertex3f(scale*cos(angle+interval), scale*sin(angle+interval), 0);

		angle += interval;


	}
	
	glTexCoord2f(0.5, 0.5);
	glNormal3f(0, 0, 1);
	glVertex3f(sin(0), cos(0), 0);
	glEnd();


}

void shape_generation::cylinder(int vertices) {
	float interval = (2 * PI) / vertices;
	float angle = 0.0f;
	glBegin(GL_QUADS);
	for (int i = 0; i < vertices/2; i++) {
		angle = 0.0f;
		for (int j = 0; j < vertices; j++) {
			glNormal3f(cos(angle + interval), sin(angle + interval), i);
			glTexCoord2f(0, 0);
			glVertex3f(cos(angle + interval), sin(angle + interval), i);


			glNormal3f(cos(angle), sin(angle), i);
			glTexCoord2f(1, 0);
			glVertex3f(cos(angle), sin(angle), i);

			glNormal3f(cos(angle), sin(angle), i - 1);
			glTexCoord2f(1, 1);
			glVertex3f(cos(angle), sin(angle),i-1);

			glNormal3f(cos(angle + interval), sin(angle + interval), i - 1);
			glTexCoord2f(0, 1);
			glVertex3f(cos(angle + interval), sin(angle + interval), i-1);



			

			angle += interval;
		}

	}

	
	glEnd();
}


void shape_generation::sphere(int vertices) {
	float interval = (2 * PI) / vertices;
	float interval2 = PI / vertices;
	float theta = 0;
	float delta = 0.0f;
	glBegin(GL_QUADS);
	for (int i = 0; i < vertices; i++) {
		theta = 0.0f;
		for (int j = 0; j < vertices; j++) {
			glTexCoord2f(0,1);
			
			glVertex3f(cos(theta)*sin(delta), cos(delta), sin(theta) * sin(delta));


			glTexCoord2f(1,1);
		
			glVertex3f(cos(theta+interval) * sin(delta), cos(delta), sin(theta+interval) * sin(delta));

			glTexCoord2f(1,0);
	
			glVertex3f(cos(theta + interval) * sin(delta+interval2), cos(delta+interval2), sin(theta + interval) * sin(delta+interval2));

			glTexCoord2f(0,0);
			
			glVertex3f(cos(theta ) * sin(delta + interval2), cos(delta + interval2), sin(theta ) * sin(delta + interval2));





			theta += interval;
		}
		delta += interval2;
	}


	glEnd();
}

