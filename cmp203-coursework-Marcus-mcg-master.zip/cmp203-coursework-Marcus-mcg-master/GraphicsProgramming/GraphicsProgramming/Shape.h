#ifndef _SHAPE_H
#define _SHAPE_H

#include "glut.h"
#include <gl/gl.h>
#include <gl/glu.h>

class Shape
{

	public:
		void render1();
		void render2();
		void render3();

};
#endif 
