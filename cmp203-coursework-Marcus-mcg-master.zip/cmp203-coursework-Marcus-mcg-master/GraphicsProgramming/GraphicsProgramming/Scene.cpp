#include "Scene.h"

// Scene constructor, initilises OpenGL
// You should add further variables to need initilised.
Scene::Scene(Input *in)
{
	// Store pointer for input class
	input = in;
		
	//OpenGL settings
	glShadeModel(GL_SMOOTH);							// Enable Smooth Shading
	glClearColor(0.39f, 0.58f, 93.0f, 1.0f);			// Cornflour Blue Background
	glClearDepth(1.0f);									// Depth Buffer Setup
	glClearStencil(0);									// Clear stencil buffer
	glEnable(GL_DEPTH_TEST);							// Enables Depth Testing
	glDepthFunc(GL_LEQUAL);								// The Type Of Depth Testing To Do
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	// Really Nice Perspective Calculations
	glLightModelf(GL_LIGHT_MODEL_LOCAL_VIEWER, 1);

	// Other OpenGL / render setting should be applied here.
	glPolygonMode(GL_FRONT, GL_LINE);

	// Initialise scene variables
	glEnable(GL_COLOR_MATERIAL); 
	glEnable(GL_LIGHTING);
	glEnable(GL_TEXTURE_2D);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glClearStencil(0);
	glEnable(GL_CULL_FACE);
	
	myTexture = SOIL_load_OGL_texture("gfx/SORA.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_MIPMAPS | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT);
	brick = SOIL_load_OGL_texture("gfx/stone_wall02.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_MIPMAPS | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT);

	skytextup = SOIL_load_OGL_texture("gfx/space_up.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_MIPMAPS | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT);
	soratext = SOIL_load_OGL_texture("gfx/sora_texImgfliphorizontal.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_MIPMAPS | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT);
	keytext = SOIL_load_OGL_texture("gfx/OathKeeperTexture.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_MIPMAPS | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT);
	keytext2 = SOIL_load_OGL_texture("gfx/OblivionKeyblade.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_MIPMAPS | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT);
	roxastext = SOIL_load_OGL_texture("gfx/roxas_texture.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_MIPMAPS | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT);
	shadow = SOIL_load_OGL_texture("gfx/imposter.png", SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_MIPMAPS | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT);
	roxas.load("models/Roxas.obj", "gfx/sora_texImg.png");
	model.load("models/SoraArmsDown.obj", "gfx/sora_texImg.png");
	key2.load("models/Oblivion.obj", "gfx/sora_texImg.png");
	key.load("models/OathKeeper.obj", "gfx/sora_texImg.png");
	//set up/ loading models and textures

	currentcam = &cam;
	
}

void Scene::handleInput(float dt)
{
	// Handle user input
	
	if (input->isKeyDown('R') || input->isKeyDown('r')) {//toggles wireframe
		if (pressed == true) {
			glPolygonMode(GL_FRONT, GL_FILL);
			pressed = false;
		}else{
			glPolygonMode(GL_FRONT, GL_LINE);
			pressed = true;
		}
		
		input->SetKeyUp('R');
	}
	mousemoved = input->getMouseX() - centrex; //calculates distance mouse moves each frame horizontallyy
	currentcam->setyaw(currentcam->getyaw() + mousemoved  * camrotate); //move cam  horizontally by amount mouse moves
	if (camset == 0) {
		

		mousemoved = input->getMouseY() - centrey; 
		cam.setpitch(cam.getpitch() - mousemoved *camrotate);// rotates camera up and down depending on distance mouse moved

		input->setMouseX(centrex);//resets mouse coords
		input->setMouseY(centrey);
		glutWarpPointer(width/2, height/2);

		if (input->isKeyDown('W') || input->isKeyDown('w')) {//moves camera forward

			cam.setcamx(cam.getcamx() + cam.getforwardx() * speed * dt);
			cam.setcamy(cam.getcamy() + cam.getforwardy() * speed * dt);
			cam.setcamz(cam.getcamz() + cam.getforwardz() * speed * dt);
		}
		if (input->isKeyDown('S') || input->isKeyDown('s')) {//moves camra back

			cam.setcamx(cam.getcamx() - cam.getforwardx() * speed * dt);
			cam.setcamy(cam.getcamy() - cam.getforwardy() * speed * dt);
			cam.setcamz(cam.getcamz() - cam.getforwardz() * speed * dt);
		}
		if (input->isKeyDown('I') || input->isKeyDown('i')) {//moves camera up

			cam.setcamx(cam.getcamx() + cam.getupx() * speed * dt);
			cam.setcamy(cam.getcamy() + cam.getupy() * speed * dt);
			cam.setcamz(cam.getcamz() + cam.getupz() * speed * dt);
		}
		if (input->isKeyDown('K') || input->isKeyDown('k')) { //moves camera down

			cam.setcamx(cam.getcamx() - cam.getupx() * speed * dt);
			cam.setcamy(cam.getcamy() - cam.getupy() * speed * dt);
			cam.setcamz(cam.getcamz() - cam.getupz() * speed * dt);
		}
	}
	if (input->isKeyDown('1')) {
		camset = 0;
		currentcam = &cam;
	}
	
	if (input->isKeyDown('2')) {//second camera has static position and only can rotate horizontally
		camset = 1;
		currentcam = &cam2;

		cam2.setcamx(0);
		cam2.setcamy(1);
		cam2.setcamz(6);
		cam2.setupx(0);
		cam2.setupy(1);
		cam2.setupz(0);
		cam2.setlookatx(0);
		cam2.setlookaty(0);
		cam2.setlookatz(0);

		cam2.setpitch(0);
		cam2.setyaw(0);
		cam2.setroll(0);

	}
}

void Scene::update(float dt)
{
	// update scene related variables.
	

	mousexpos = input->getMouseX();
	mouseypos = input->getMouseY();
	input->setMouseX(centrex);//resets mouse coords
	input->setMouseY(centrey);
	glutWarpPointer(width / 2, height / 2);
	cam.update(dt);
	cam2.update(dt);

	// Calculate FPS for output
	rotation += speed * dt;
	calculateFPS();
}

void Scene::render() {

	// Clear Color and Depth Buffers
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

	// Reset transformations
	glLoadIdentity();
	// Set the camera
	
	gluLookAt(currentcam->getcamx(), currentcam->getcamy(), currentcam->getcamz(), currentcam->getlookatx(), currentcam->getlookaty(), currentcam->getlookatz(), currentcam->getupx(), currentcam->getupy(), currentcam->getupz());
	// Render geometry/scene here -------------------------------------
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
	skybox();//renders skybox first

	GLfloat Light_Diffuse1[] = { 0.5, 0.5f,0.50f, 1.0f };
	GLfloat Light_Position1[] = { 0.0f, 1.0f, 0.0f, 0.0f };//initial direction light down y axis
	glLightfv(GL_LIGHT0, GL_DIFFUSE, Light_Diffuse1);
	glLightfv(GL_LIGHT0, GL_POSITION, Light_Position1);
	glEnable(GL_LIGHT0);
	//red spotlight
	GLfloat Light_Ambient2[] = { 0.1, 0.1f, 0.1f, 1.0f };
	GLfloat Light_Diffuse2[] = { 1.0, 0.0, 0.0f, 1.0f };
	GLfloat Light_Position2[] = { 5.0f, 0.5f, 0.0f, 1.0f };
	GLfloat spot_Direction2[] = { -1.0f, 0.0f, 0.0f };

	glLightfv(GL_LIGHT2, GL_AMBIENT, Light_Ambient2);
	glLightfv(GL_LIGHT2, GL_DIFFUSE, Light_Diffuse2);
	glLightfv(GL_LIGHT2, GL_POSITION, Light_Position2);
	glLightf(GL_LIGHT2, GL_SPOT_CUTOFF, 90.0f);
	glLightfv(GL_LIGHT2, GL_SPOT_DIRECTION, spot_Direction2);
	glLightf(GL_LIGHT2, GL_SPOT_EXPONENT, 100.0);
	glEnable(GL_LIGHT2);


	glPushMatrix();
		glEnable(GL_BLEND);//draw shadow as a transparent disc for sora and keyblade models
		glBindTexture(GL_TEXTURE_2D, shadow);
		glPushMatrix();
			glTranslatef(0, 0.01, 0);
			glRotatef(270, 1, 0, 0);
			glColor4f(1, 1, 1, 0.9);
			glScalef(0.06, 0.06, 0.06);
		
			myshape.disc(150, 5);
		glPopMatrix();
		glPushMatrix();
			glTranslatef(0.25, 0.01, 1);
			glScalef(0.03, 0.03, 0.03);
			glRotatef(270, 1, 0, 0);
			myshape.disc(150, 5);
		glPopMatrix();
		glDisable(GL_BLEND);
	glPopMatrix();

	glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);//stencil buffer used for reflections on glass floor
	glEnable(GL_STENCIL_TEST);
	glStencilFunc(GL_ALWAYS, 1, 1);
	glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);
	glDisable(GL_DEPTH_TEST);
	glPushMatrix();
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_SRC_ALPHA);
		glRotatef(270, 1, 0, 0);
		glScalef(2, 2, 2);
		glColor4f(1, 1, 1, 0.9);
		glBindTexture(GL_TEXTURE_2D, myTexture);
		myshape.disc(150, 5); //draws the floor
		glDisable(GL_BLEND);
	glPopMatrix();
	glEnable(GL_DEPTH_TEST);
	glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
	glStencilFunc(GL_EQUAL, 1, 1);
	glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);
	glPushMatrix();
		glBindTexture(GL_TEXTURE_2D, roxastext);//draws reflection objects first
		glRotatef(180, 0, 0, 1);
		glScalef(0.07, 0.07, 0.07);
		roxas.render();
	glPopMatrix();
	glPushMatrix();
		glTranslatef(0, -1.25, 1);
		glRotatef(270, 1, 0, 0);
		glRotatef(15, 0, 1, 0);
		glScalef(0.01, 0.01, 0.01);
		glBindTexture(GL_TEXTURE_2D, keytext2);
		key2.render();
	glPopMatrix();

	glDisable(GL_STENCIL_TEST);
	glEnable(GL_BLEND);
	glDisable(GL_LIGHTING);
	glPushMatrix();
	glRotatef(270, 1, 0, 0);
	glScalef(2, 2, 2);
	glColor4f(1, 1, 1, 0.5);
	glBindTexture(GL_TEXTURE_2D, myTexture);//draw the floor again
	myshape.disc(150, 5);
	glPopMatrix();
	glEnable(GL_LIGHTING);
	glDisable(GL_BLEND);
	glPushMatrix();
	glBindTexture(GL_TEXTURE_2D, soratext);//draw the original models above the reflective floor
		glTranslatef(0, 0.01, 0);
		glScalef(0.01, 0.01, 0.01);
		model.render();
	glPopMatrix();
	glPushMatrix();
		glTranslatef(0, -0.5, 0);
		glRotatef(rotation, 0, 90, 0);
		gluSphere(gluNewQuadric(), 0.02, 20, 20);//draws tiny sphere for sake of rotating obects around the centre
		glPushMatrix();
			glBindTexture(GL_TEXTURE_2D, skytextup);//draws the cube  and rotates it in a circle around the centre sphere
			//glColor3f(0, 0, 1);
			glTranslatef(20, 1, 0);
			glRotatef(rotation, 0, 1, 1);
			r1.render2();
			glPushMatrix();
				glTranslatef(0, 5, 0);
				glRotatef(rotation, 1, 1, 1);
				r1.render2();
			glPopMatrix();
			glPushMatrix();
				glTranslatef(0, -5, 0);
				glRotatef(rotation, 0, 1, 1);
				r1.render2();
			glPopMatrix();
			GLfloat Light_Diffuse[] = { 0.0, 1.0f, 1, 0 };//creates a light that revolves with the cube and lights the keyblade making it look as if it glows
			GLfloat Light_Position[] = { 1, 0, 0, 1 };
			glLightfv(GL_LIGHT1, GL_DIFFUSE, Light_Diffuse);
			glLightfv(GL_LIGHT1, GL_POSITION, Light_Position);
			glEnable(GL_LIGHT1);

		glPopMatrix();
	glPopMatrix();
	glPushMatrix();
	glTranslatef(0, 0.9, 1);
	glRotatef(90, 1, 0, 0);
	glRotatef(20, 0, 1, 0);
	glScalef(0.01, 0.01, 0.01);
	glBindTexture(GL_TEXTURE_2D, keytext);
	key.render();
	glPopMatrix();


	
	glPushMatrix();
		glRotatef(90, 1, 0, 0);//sets up and draws the cylinder
		glScalef(10, 10, 1);
		glTranslatef(0, 0, 1);
		glBindTexture(GL_TEXTURE_2D,brick );
		myshape.cylinder(50);
	glPopMatrix();
	
	// End render geometry --------------------------------------

	// Render text, should be last object rendered.
	renderTextOutput();
	
	// Swap buffers, after all objects are rendered.
	glutSwapBuffers();
}

// Handles the resize of the window. If the window changes size the perspective matrix requires re-calculation to match new window size.
void Scene::resize(int w, int h) 
{
	width = w;
	height = h;
	centrex = width / 2;
	centrey = height / 2;
	// Prevent a divide by zero, when window is too short
	// (you cant make a window of zero width).
	if (h == 0)
		h = 1;

	float ratio = (float)w / (float)h;
	fov = 45.0f;
	nearPlane = 0.1f;
	farPlane = 100.0f;

	// Use the Projection Matrix
	glMatrixMode(GL_PROJECTION);

	// Reset Matrix
	glLoadIdentity();

	// Set the viewport to be the entire window
	glViewport(0, 0, w, h);

	// Set the correct perspective.
	gluPerspective(fov, ratio, nearPlane, farPlane);

	// Get Back to the Modelview
	glMatrixMode(GL_MODELVIEW);






	
}

// Calculates FPS
void Scene::calculateFPS()
{

	frame++;
	time = glutGet(GLUT_ELAPSED_TIME);

	if (time - timebase > 1000) {
		sprintf_s(fps, "FPS: %4.2f", frame*1000.0 / (time - timebase));
		timebase = time;
		frame = 0;
	}
}

// Compiles standard output text including FPS and current mouse position.
void Scene::renderTextOutput()
{
	// Render current mouse position and frames per second.
	sprintf_s(mouseText, "Mouse: %i, %i", input->getMouseX(), input->getMouseY());
	displayText(-1.f, 0.96f, 1.f, 0.f, 0.f, mouseText);
	displayText(-1.f, 0.90f, 1.f, 0.f, 0.f, fps);
}

// Renders text to screen. Must be called last in render function (before swap buffers)
void Scene::displayText(float x, float y, float r, float g, float b, char* string) {
	// Get Lenth of string
	int j = strlen(string);

	// Swap to 2D rendering
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-1.0, 1.0, -1.0, 1.0, 5, 100);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	// Orthographic lookAt (along the z-axis).
	gluLookAt(0.0f, 0.0f, 10.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f);

	// Set text colour and position.
	glColor3f(r, g, b);
	glRasterPos2f(x, y);
	// Render text.
	for (int i = 0; i < j; i++) {
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, string[i]);
	}
	// Reset colour to white.
	glColor3f(1.f, 1.f, 1.f);

	// Swap back to 3D rendering.
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(fov, ((float)width/(float)height), nearPlane, farPlane);
	glMatrixMode(GL_MODELVIEW);
}

void Scene::skybox() {
	
	
		glPushMatrix();
		
	glTranslatef(currentcam->getcamx(), currentcam->getcamy(), currentcam->getcamz());
	glDisable(GL_LIGHTING);
	glDisable(GL_DEPTH_TEST);// depth test disabed so sky box appears behnd all objects
	glBindTexture(GL_TEXTURE_2D, skytextup);
	

	//FRONT
	glBegin(GL_QUADS);
	glTexCoord2f(0.25,0.33);
	glVertex3f(-0.5, -0.5, -0.5);

	glTexCoord2f(0.5,0.33);
	glVertex3f(0.5, -0.5, -0.5);

	glTexCoord2f(0.5,0.66);
	glVertex3f(0.5, 0.5, -0.5);

	glTexCoord2f(0.25,0.66);
	glVertex3f(-0.5, 0.5, -0.5);

	glEnd();

	//Back
	
	glBegin(GL_QUADS);
	glTexCoord2f(0.75,0.33);
	glVertex3f(0.5, -0.5, 0.5);

	glTexCoord2f(1,0.33);
	glVertex3f(-0.5, -0.5, 0.5);

	glTexCoord2f(1,0.66);
	glVertex3f(-0.5, 0.5, 0.5);

	glTexCoord2f(0.75,0.66);
	glVertex3f(0.5, 0.5, 0.5);
	glEnd();


	//left
	
	glBegin(GL_QUADS);
	glTexCoord2f(0,0.33);
	glVertex3f(-0.5, -0.5, 0.5);

	glTexCoord2f(0.25,0.33);
	glVertex3f(-0.5, -0.5, -0.5);

	glTexCoord2f(0.25,0.66);
	glVertex3f(-0.5, 0.5, -0.5);

	glTexCoord2f(0,0.66);
	glVertex3f(-0.5, 0.5, 0.5);
	glEnd();

	//right
	
	glBegin(GL_QUADS);
	glTexCoord2f(0.5,0.33);
	glVertex3f(0.5, -0.5, -0.5);

	glTexCoord2f(0.75,0.33);
	glVertex3f(0.5, -0.5, 0.5);

	glTexCoord2f(0.75,0.66);
	glVertex3f(0.5, 0.5, 0.5);

	glTexCoord2f(0.5,0.66);
	glVertex3f(0.5, 0.5, -0.5);
	glEnd();

	//bottom

	glBegin(GL_QUADS);
	glTexCoord2f(0.25,0.66);
	glVertex3f(-0.5, -0.5, 0.5);

	glTexCoord2f(0.5,0.66);
	glVertex3f(0.5, -0.5, 0.5);

	glTexCoord2f(0.5,1);
	glVertex3f(0.5, -0.5, -0.5);

	glTexCoord2f(0.25,1);
	glVertex3f(-0.5, -0.5, -0.5);
	glEnd();

	//TOP
	
	glBegin(GL_QUADS);
	glTexCoord2f(0.25,0);
	glVertex3f(-0.5, 0.5, -0.5);

	glTexCoord2f(0.5,0);
	glVertex3f(0.5, 0.5, -0.5);

	glTexCoord2f(0.5,0.33);
	glVertex3f(0.5, 0.5, 0.5);

	glTexCoord2f(0.25,0.33);
	glVertex3f(-0.5, 0.5, 0.5);

	glEnd();

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	glPopMatrix();


}