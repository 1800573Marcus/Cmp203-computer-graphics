#pragma once
#include "Input.h"
#include <iostream>
class Camera
{
public:

	float getpitch();
	void setpitch(float p);
	float getyaw();
	void setyaw(float y);
	float getroll();
	void setroll(float r);

	float getcamx();
	void setcamx(float p);
	float getcamy();
	void setcamy(float y);
	float getcamz();
	void setcamz(float r);

	float getlookatx();
	void setlookatx(float x);
	float getlookaty();
	void setlookaty(float y);
	float getlookatz();
	void setlookatz(float z);

	float getupx();
	void setupx(float x);
	float getupy();
	void setupy(float y);
	float getupz();
	void setupz(float z);

	float getforwardx();
	void setforwardx(float x);
	float getforwardy();
	void setforwardy(float y);
	float getforwardz();
	void setforwardz(float z);

	void update(float dt);
protected:


	

	float pitch = 0;
	float yaw = 0;
	float roll = 0;

	float camx = 0;
	float camy = 0;
	float camz = 6;

	float forwardx = 0;
	float forwardy = 0;
	float forwardz = 0;

	float lookatx = 0;
	float lookaty = 0;
	float lookatz = 0;

	float upx = 0;
	float upy = 1;
	float upz = 0;
};

