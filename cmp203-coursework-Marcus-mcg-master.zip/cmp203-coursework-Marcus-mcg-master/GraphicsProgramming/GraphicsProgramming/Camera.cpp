#include "Camera.h"


float Camera::getpitch() {
	return pitch;
}
void Camera::setpitch(float p) {
	pitch = p;

}
float Camera::getyaw() {
	return yaw;
}
void Camera::setyaw(float y) {
	yaw = y;

}
float Camera::getroll() {
	return roll;
}
void Camera::setroll(float r) {
	roll = r;

}



float Camera::getcamx() {
	return camx;
}
void Camera::setcamx(float x) {
	camx = x;

}
float Camera::getcamy() {
	return camy;
}
void Camera::setcamy(float y) {
	camy= y;

}
float Camera::getcamz() {
	return camz;
}
void Camera::setcamz(float z) {
	camz = z;

}

float Camera::getlookatx() {
	return lookatx;
}
void Camera::setlookatx(float x) {
	lookatx = x;

}
float Camera::getlookaty() {
	return lookaty;
}
void Camera::setlookaty(float y) {
	lookaty = y;

}
float Camera::getlookatz() {
	return lookatz;
}
void Camera::setlookatz(float z) {
	lookatz = z;

}

float Camera::getupx() {
	return upx;
}
void Camera::setupx(float x) {
	upx = x;

}
float Camera::getupy() {
	return upy;
}
void Camera::setupy(float y) {
	upy = y;
}
float Camera::getupz() {
	return upz;
}
void Camera::setupz(float z) {
	upz = z;

}
float Camera::getforwardx() {
	return forwardx;
}
void Camera::setforwardx(float x) {
	forwardx = x;

}
float Camera::getforwardy() {
	return forwardy;
}
void Camera::setforwardy(float y) {
	forwardy = y;
}
float Camera::getforwardz() {
	return forwardz;
}
void Camera::setforwardz(float z) {
	forwardz = z;

}
void Camera::update(float dt) {


	float cosR, cosP, cosY;//temp values for sin/cos from 
	float sinR, sinP, sinY;

	cosY = cosf(yaw * 3.1415 / 180); 
	cosP = cosf(pitch * 3.1415 / 180); 
	cosR = cosf(roll * 3.1415 / 180);
	sinY = sinf(yaw * 3.1415 / 180); 
	sinP = sinf(pitch * 3.1415 / 180);
	sinR = sinf(roll * 3.1415 / 180);

	forwardx = sinY * cosP;
	forwardy = sinP;
	forwardz = cosP * -cosY;

	lookatx = camx + forwardx;
	lookaty = camy + forwardy;
	lookatz = camz + forwardz;


	upx = -cosY * sinR - sinY * sinP * cosR;
	upy = cosP * cosR;
	upz = -sinY * sinR - sinP * cosR * -cosY;


}
